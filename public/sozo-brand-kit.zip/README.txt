SOZO identity

Symbol: recreated from your supplied reference.
Primary color: #CEFF39
Charcoal: #171D19

SVG files scale to any size. Mark PNG is transparent. Logo PNG has a charcoal background. Wordmark PNG is transparent. Keep clear space around the symbol.
